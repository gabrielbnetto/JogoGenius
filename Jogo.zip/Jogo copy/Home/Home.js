function mudarPagina(){
    alert("Ola")
    setTimeout("location.href = 'file:///Users/gabrieldiasmarinho/Documents/Mackenzie-2%C2%BA:2018/Fatores%20de%20Sistemas/Projeto/Jogo/Jogo/Jogo.html';",1500);
}